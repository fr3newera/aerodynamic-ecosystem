<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('panel_orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('egg_id');
            $table->unsignedInteger('server_id')->nullable();

            $table->string('name');
            $table->text('description')->nullable();

            $table->string('spec_key');
            $table->unsignedInteger('memory');
            $table->unsignedInteger('cpu')->default(0);
            $table->unsignedInteger('disk')->default(0);

            $table->unsignedInteger('price');

            $table->string('trx_id')->unique();
            $table->string('qr_string')->nullable();
            $table->unsignedInteger('total_transfer')->nullable();
            $table->unsignedInteger('unique_code')->nullable();
            $table->timestamp('expires_at')->nullable();

            $table->string('status')->default('PENDING');

            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('egg_id')->references('id')->on('eggs')->onDelete('cascade');
            $table->foreign('server_id')->references('id')->on('servers')->onDelete('set null');

            $table->index(['user_id', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('panel_orders');
    }
};
