<?php

return [
    /*
    |--------------------------------------------------------------------------
    | FR3NEWERA Payment Gateway
    |--------------------------------------------------------------------------
    |
    | These values act only as fallback defaults. In practice they are
    | overridden at runtime by values stored in the database, which are
    | managed from Admin -> Settings -> FR3NEWERA Configuration.
    |
    */

    'enabled' => false,

    'api_key' => null,

    'base_url' => 'https://fr3newera.com',

    // When true, the 2% MDR fee is added on top of the amount the customer
    // pays via QRIS. When false, the MDR is deducted from the amount that
    // lands in your FR3NEWERA balance.
    'add_mdr_to_customer' => false,
];
