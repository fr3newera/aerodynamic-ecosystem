<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Server Specification Catalog
    |--------------------------------------------------------------------------
    |
    | Each entry defines a purchasable server specification. "memory", "cpu"
    | and "disk" follow the same units as the Pterodactyl server model:
    | memory/disk in MB (0 = unlimited), cpu in percent (0 = unlimited).
    | "price" is in Rupiah (IDR) and is what gets sent to FR3NEWERA as the
    | topup nominal.
    |
    */

    'specs' => [
        'unlimited' => [
            'label' => 'Ram Unlimited',
            'price' => 12000,
            'memory' => 0,
            'cpu' => 0,
            'disk' => 0,
        ],
        '1gb' => [
            'label' => 'Ram 1GB',
            'price' => 1000,
            'memory' => 1024,
            'cpu' => 50,
            'disk' => 2048,
        ],
        '2gb' => [
            'label' => 'Ram 2GB',
            'price' => 2000,
            'memory' => 2048,
            'cpu' => 60,
            'disk' => 3072,
        ],
        '3gb' => [
            'label' => 'Ram 3GB',
            'price' => 3000,
            'memory' => 3072,
            'cpu' => 70,
            'disk' => 4096,
        ],
        '4gb' => [
            'label' => 'Ram 4GB',
            'price' => 4000,
            'memory' => 4096,
            'cpu' => 80,
            'disk' => 5120,
        ],
        '5gb' => [
            'label' => 'Ram 5GB',
            'price' => 5000,
            'memory' => 5120,
            'cpu' => 90,
            'disk' => 6144,
        ],
        '6gb' => [
            'label' => 'Ram 6GB',
            'price' => 6000,
            'memory' => 6144,
            'cpu' => 100,
            'disk' => 7168,
        ],
        '7gb' => [
            'label' => 'Ram 7GB',
            'price' => 7000,
            'memory' => 7168,
            'cpu' => 110,
            'disk' => 8192,
        ],
        '8gb' => [
            'label' => 'Ram 8GB',
            'price' => 8000,
            'memory' => 8192,
            'cpu' => 120,
            'disk' => 9216,
        ],
        '9gb' => [
            'label' => 'Ram 9GB',
            'price' => 9000,
            'memory' => 9216,
            'cpu' => 130,
            'disk' => 10240,
        ],
        '10gb' => [
            'label' => 'Ram 10GB',
            'price' => 10000,
            'memory' => 10240,
            'cpu' => 140,
            'disk' => 11264,
        ],
    ],
];
