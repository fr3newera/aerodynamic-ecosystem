<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Pterodactyl\Models\PanelOrder.
 *
 * @property int $id
 * @property int $user_id
 * @property int $egg_id
 * @property int|null $server_id
 * @property string $name
 * @property string|null $description
 * @property string $spec_key
 * @property int $memory
 * @property int $cpu
 * @property int $disk
 * @property int $price
 * @property string $trx_id
 * @property string|null $qr_string
 * @property int|null $total_transfer
 * @property int|null $unique_code
 * @property \Illuminate\Support\Carbon|null $expires_at
 * @property string $status
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property User $user
 * @property Egg $egg
 * @property Server|null $server
 */
class PanelOrder extends Model
{
    public const RESOURCE_NAME = 'panel_order';

    public const STATUS_PENDING = 'PENDING';
    public const STATUS_SUCCESS = 'SUCCESS';
    public const STATUS_EXPIRED = 'EXPIRED';
    public const STATUS_CANCELED = 'CANCELED';
    public const STATUS_FAILED = 'FAILED';
    public const STATUS_PROVISIONED = 'PROVISIONED';

    protected $table = 'panel_orders';

    protected $fillable = [
        'user_id',
        'egg_id',
        'server_id',
        'name',
        'description',
        'spec_key',
        'memory',
        'cpu',
        'disk',
        'price',
        'trx_id',
        'qr_string',
        'total_transfer',
        'unique_code',
        'expires_at',
        'status',
    ];

    protected $casts = [
        'user_id' => 'integer',
        'egg_id' => 'integer',
        'server_id' => 'integer',
        'memory' => 'integer',
        'cpu' => 'integer',
        'disk' => 'integer',
        'price' => 'integer',
        'total_transfer' => 'integer',
        'unique_code' => 'integer',
        'expires_at' => 'datetime',
    ];

    public static array $validationRules = [
        'user_id' => 'required|integer|exists:users,id',
        'egg_id' => 'required|integer|exists:eggs,id',
        'server_id' => 'nullable|integer|exists:servers,id',
        'name' => 'required|string|max:191',
        'description' => 'nullable|string',
        'spec_key' => 'required|string|max:64',
        'memory' => 'required|integer|min:0',
        'cpu' => 'required|integer|min:0',
        'disk' => 'required|integer|min:0',
        'price' => 'required|integer|min:0',
        'trx_id' => 'required|string|max:191',
        'status' => 'required|string|max:32',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function egg(): BelongsTo
    {
        return $this->belongsTo(Egg::class);
    }

    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isPaid(): bool
    {
        return in_array($this->status, [self::STATUS_SUCCESS, self::STATUS_PROVISIONED], true);
    }

    /**
     * This model does not use a UUID for route binding, use the numeric
     * primary key instead.
     */
    public function getRouteKeyName(): string
    {
        return 'id';
    }
}
