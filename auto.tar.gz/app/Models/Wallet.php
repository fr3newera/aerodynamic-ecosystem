<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\Wallet.
 *
 * @property int $id
 * @property int $user_id
 * @property int $balance Balance stored in whole Rupiah (integer, no decimals).
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Pterodactyl\Models\User $user
 */
class Wallet extends Model
{
    public const RESOURCE_NAME = 'wallet';

    protected $table = 'wallets';

    protected $fillable = [
        'user_id',
        'balance',
    ];

    public static array $validationRules = [
        'user_id' => 'required|integer|exists:users,id',
        'balance' => 'integer|min:0',
    ];

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Find (or lazily create) the wallet belonging to the given user.
     */
    public static function forUser(int $userId): self
    {
        return self::query()->firstOrCreate(['user_id' => $userId], ['balance' => 0]);
    }
}
