<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\ServerOrder.
 *
 * @property int $id
 * @property int $user_id
 * @property int|null $server_id
 * @property int $egg_id
 * @property string $name
 * @property string|null $description
 * @property int $memory
 * @property int $cpu
 * @property int $disk
 * @property int $price
 * @property string $status
 * @property string|null $failure_reason
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Pterodactyl\Models\User $user
 * @property \Pterodactyl\Models\Server|null $server
 * @property \Pterodactyl\Models\Egg $egg
 */
class ServerOrder extends Model
{
    public const RESOURCE_NAME = 'server_order';

    protected $table = 'server_orders';

    protected $fillable = [
        'user_id',
        'server_id',
        'egg_id',
        'name',
        'description',
        'memory',
        'cpu',
        'disk',
        'price',
        'status',
        'failure_reason',
    ];

    public static array $validationRules = [
        'user_id' => 'required|integer|exists:users,id',
        'egg_id' => 'required|integer|exists:eggs,id',
        'name' => 'required|string|between:1,191',
        'memory' => 'required|integer|min:0',
        'cpu' => 'required|integer|min:0',
        'disk' => 'required|integer|min:0',
        'price' => 'required|integer|min:0',
    ];

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function server(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    public function egg(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Egg::class);
    }
}
