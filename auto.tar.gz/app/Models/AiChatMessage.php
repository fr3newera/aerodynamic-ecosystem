<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\AiChatMessage.
 *
 * @property int $id
 * @property int $user_id
 * @property int $server_id
 * @property string $role
 * @property string|null $content
 * @property array|null $tool_calls
 * @property string|null $tool_call_id
 * @property string|null $tool_name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Pterodactyl\Models\User $user
 * @property \Pterodactyl\Models\Server $server
 */
class AiChatMessage extends Model
{
    public const RESOURCE_NAME = 'ai_chat_message';

    public const ROLE_USER = 'user';
    public const ROLE_ASSISTANT = 'assistant';
    public const ROLE_TOOL = 'tool';
    public const ROLE_SYSTEM = 'system';

    protected $table = 'ai_chat_messages';

    protected $fillable = [
        'user_id',
        'server_id',
        'role',
        'content',
        'tool_calls',
        'tool_call_id',
        'tool_name',
    ];

    protected $casts = [
        'tool_calls' => 'array',
    ];

    public static array $validationRules = [
        'user_id' => 'required|integer|exists:users,id',
        'server_id' => 'required|integer|exists:servers,id',
        'role' => 'required|in:user,assistant,tool,system',
    ];

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function server(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Server::class);
    }
}
