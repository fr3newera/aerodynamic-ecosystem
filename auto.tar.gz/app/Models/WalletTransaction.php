<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\WalletTransaction.
 *
 * @property int $id
 * @property int $user_id
 * @property string $trx_id
 * @property string $type
 * @property string $status
 * @property int $amount
 * @property int|null $total_transfer
 * @property int|null $unique_code
 * @property string|null $qr_string
 * @property \Illuminate\Support\Carbon|null $expires_at
 * @property string|null $description
 * @property array|null $meta
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Pterodactyl\Models\User $user
 */
class WalletTransaction extends Model
{
    public const RESOURCE_NAME = 'wallet_transaction';

    public const TYPE_TOPUP = 'topup';
    public const TYPE_PURCHASE = 'purchase';
    public const TYPE_REFUND = 'refund';

    public const STATUS_PENDING = 'PENDING';
    public const STATUS_SUCCESS = 'SUCCESS';
    public const STATUS_EXPIRED = 'EXPIRED';
    public const STATUS_CANCELED = 'CANCELED';
    public const STATUS_FAILED = 'FAILED';

    protected $table = 'wallet_transactions';

    protected $fillable = [
        'user_id',
        'trx_id',
        'type',
        'status',
        'amount',
        'total_transfer',
        'unique_code',
        'qr_string',
        'expires_at',
        'description',
        'meta',
    ];

    protected $casts = [
        'meta' => 'array',
        'expires_at' => 'datetime',
    ];

    public static array $validationRules = [
        'user_id' => 'required|integer|exists:users,id',
        'trx_id' => 'required|string|unique:wallet_transactions,trx_id',
        'type' => 'required|in:topup,purchase,refund',
        'status' => 'required|in:PENDING,SUCCESS,EXPIRED,CANCELED,FAILED',
        'amount' => 'required|integer',
    ];

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
