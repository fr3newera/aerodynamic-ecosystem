<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\RegistrationCode.
 *
 * @property int $id
 * @property string $code
 * @property bool $is_used
 * @property int|null $used_by_user_id
 * @property \Illuminate\Support\Carbon|null $used_at
 * @property int|null $created_by_user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Pterodactyl\Models\User|null $usedBy
 * @property \Pterodactyl\Models\User|null $createdBy
 */
class RegistrationCode extends Model
{
    /**
     * The resource name for this model when it is transformed into an
     * API representation using fractal.
     */
    public const RESOURCE_NAME = 'registration_code';

    /**
     * The table associated with the model.
     */
    protected $table = 'registration_codes';

    /**
     * Fields that are mass assignable.
     */
    protected $fillable = [
        'code',
        'is_used',
        'used_by_user_id',
        'used_at',
        'created_by_user_id',
    ];

    /**
     * Cast values to correct type.
     */
    protected $casts = [
        'is_used' => 'boolean',
        'used_at' => 'datetime',
    ];

    /**
     * Rules verifying that the data being stored matches the expectations of the database.
     */
    public static array $validationRules = [
        'code' => 'required|string|between:4,64|unique:registration_codes,code',
        'is_used' => 'boolean',
        'used_by_user_id' => 'nullable|integer|exists:users,id',
        'created_by_user_id' => 'nullable|integer|exists:users,id',
    ];

    /**
     * This model does not have a uuid column, so route model binding
     * must use the numeric id instead of the default uuid key.
     */
    public function getRouteKeyName(): string
    {
        return 'id';
    }

    public function usedBy(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'used_by_user_id');
    }

    public function createdBy(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_user_id');
    }

    /**
     * Generate a random, unique, human-friendly registration code.
     */
    public static function generateCode(): string
    {
        do {
            $code = mb_strtoupper(bin2hex(random_bytes(4))) . '-' . mb_strtoupper(bin2hex(random_bytes(4)));
        } while (self::query()->where('code', $code)->exists());

        return $code;
    }
}
