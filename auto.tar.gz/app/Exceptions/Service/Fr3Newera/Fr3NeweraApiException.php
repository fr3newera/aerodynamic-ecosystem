<?php

namespace Pterodactyl\Exceptions\Service\Fr3Newera;

use Pterodactyl\Exceptions\DisplayException;

class Fr3NeweraApiException extends DisplayException
{
}
