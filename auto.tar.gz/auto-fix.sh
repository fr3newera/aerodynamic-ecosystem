#!/bin/bash
set -e

echo "=============================================="
echo " AUTO FIX - Pterodactyl Registration Feature"
echo "=============================================="

cd /var/www/pterodactyl || { echo "GAGAL: folder /var/www/pterodactyl tidak ditemukan"; exit 1; }

echo ""
echo "[1/8] Cek file backend..."
MISSING=0
for f in \
  "app/Http/Controllers/Admin/RegistrationCodeController.php" \
  "app/Http/Controllers/Auth/RegistrationController.php" \
  "app/Models/RegistrationCode.php" \
  "resources/views/admin/registration-codes/index.blade.php" \
  "database/migrations/2026_08_25_000001_create_registration_codes_table.php" \
  "resources/scripts/components/auth/RegisterContainer.tsx" \
  "resources/scripts/api/auth/register.ts" \
  "app/Models/Wallet.php" \
  "app/Models/WalletTransaction.php" \
  "app/Models/ServerOrder.php" \
  "app/Services/Payments/Fr3NeweraGatewayService.php" \
  "app/Services/Store/StoreConfigService.php" \
  "app/Http/Controllers/Api/Client/StoreController.php" \
  "app/Http/Controllers/Admin/StoreSettingsController.php" \
  "resources/views/admin/store/index.blade.php" \
  "resources/scripts/components/dashboard/CreateServerModal.tsx" \
  "resources/scripts/components/dashboard/WalletContainer.tsx" \
  "resources/scripts/api/store/getStoreConfig.ts" \
  "resources/scripts/api/store/wallet.ts" \
  "database/migrations/2026_08_25_000002_create_wallets_table.php" \
  "database/migrations/2026_08_25_000003_create_server_orders_table.php" \
  "database/migrations/2026_08_25_000004_create_ai_agent_tables.php" \
  "app/Models/AiChatMessage.php" \
  "app/Services/AiAgent/AiAgentConfigService.php" \
  "app/Services/AiAgent/OpenRouterService.php" \
  "app/Services/AiAgent/AiAgentToolExecutor.php" \
  "app/Services/AiAgent/AiAgentConversationService.php" \
  "app/Http/Requests/Api/Client/Servers/AiAgent/SendAiMessageRequest.php" \
  "app/Http/Requests/Api/Client/Servers/AiAgent/ViewAiChatRequest.php" \
  "app/Http/Controllers/Api/Client/Servers/AiAgentController.php" \
  "app/Http/Controllers/Admin/AiAgentSettingsController.php" \
  "resources/views/admin/ai-agent/index.blade.php" \
  "resources/scripts/api/server/aiAgent.ts" \
  "resources/scripts/components/server/aiagent/AiAgentContainer.tsx"
do
  if [ ! -f "$f" ]; then
    echo "  HILANG: $f"
    MISSING=1
  fi
done

if [ "$MISSING" = "1" ]; then
  echo ""
  echo "!! ADA FILE YANG BELUM TER-UPLOAD (lihat daftar di atas)."
  echo "!! Upload ulang file yang HILANG itu ke server sebelum lanjut."
  exit 1
fi
echo "  OK, semua file backend ada."

echo ""
echo "[2/8] Fix permission storage & cache..."
chown -R www-data:www-data storage bootstrap/cache 2>/dev/null || true
chmod -R 775 storage bootstrap/cache

echo ""
echo "[3/8] Reset tabel registration_codes kalau bentrok..."
DB_DATABASE=$(grep -m1 "^DB_DATABASE=" .env | cut -d '=' -f2)
DB_USERNAME=$(grep -m1 "^DB_USERNAME=" .env | cut -d '=' -f2)
DB_PASSWORD=$(grep -m1 "^DB_PASSWORD=" .env | cut -d '=' -f2)
if [ -n "$DB_DATABASE" ]; then
  mysql -u "$DB_USERNAME" -p"$DB_PASSWORD" -e "USE \`$DB_DATABASE\`; DROP TABLE IF EXISTS registration_codes;" 2>/dev/null || echo "  (skip, tidak masalah kalau tabel belum ada)"
fi

echo ""
echo "[4/8] Jalankan migration..."
php artisan migrate --force

echo ""
echo "[5/8] Clear semua cache Laravel..."
php artisan optimize:clear

echo ""
echo "[6/8] Cek dan build ulang frontend (React)..."
if command -v yarn >/dev/null 2>&1; then
  yarn install --silent
  yarn build:production
elif command -v npm >/dev/null 2>&1; then
  npm install --silent
  npm run build:production
else
  echo "  GAGAL: yarn/npm tidak ditemukan di server, install dulu manual."
  exit 1
fi

echo ""
echo "[7/8] Fix permission ulang setelah build..."
chown -R www-data:www-data /var/www/pterodactyl

echo ""
echo "[8/8] Restart queue worker (kalau ada)..."
php artisan queue:restart || true

echo ""
echo "=============================================="
echo " SELESAI. Coba buka:"
echo "  - https://domainmu/auth/login   (harus ada tombol Daftar)"
echo "  - Admin -> Registration Codes"
echo "=============================================="
