const colors = require('tailwindcss/colors');

// FR3NEWERA design tokens, ported from https://fr3newera.com.
//
// These only apply to the user-facing React panel (see `content` below); the Blade
// admin panel uses a completely separate AdminLTE stylesheet and is unaffected.
//
// The identity is carried almost entirely by a single blue ramp sitting on cool,
// blue-shifted neutrals. 600 is the brand colour; 700-950 are the deep navies used
// for hero bands, gradients and the floating dock.
//
// 50 and 100 are the exception: they are pale *tints*, only ever used as a fill
// behind a blue glyph (icon tiles, hover chips, selected cards). A near-white fill
// is wrong on a dark page, so those two follow the theme; 200 upward are identical
// in both, since brand colour should not shift.
const blue = {
    50: 'rgb(var(--fr-blue-50))',
    100: 'rgb(var(--fr-blue-100))',
    200: '#C7DBFF',
    300: '#93BBFF',
    400: '#5B9BFF',
    500: '#2275FF',
    600: '#0F62FE', // brand
    700: '#0F3480',
    800: '#0D2251',
    900: '#0B1836',
    950: '#040E24',
};

// Slate, shifted very slightly cool so it sits under the blue ramp without
// reading as neutral grey.
//
// The neutral ramp and the semantic surfaces resolve through CSS custom properties
// (declared in assets/tailwind.css), so the admin-selected theme is a variable swap
// on `html[data-theme]` rather than a second set of utility classes on every
// element. The blue ramp above is deliberately NOT variable-backed: brand colour is
// identical in both themes, exactly as on the reference site.
//
// Note the absent `<alpha-value>` placeholder. twin.macro 2.8 — which resolves every
// `tw` template literal in this codebase at build time — emits that placeholder
// verbatim and produces invalid CSS. The two places that genuinely need a translucent
// neutral write `rgb(var(--fr-gray-N) / <alpha>)` by hand instead.
const varColor = name => `rgb(var(${name}))`;

const gray = {
    50: varColor('--fr-gray-50'),
    100: varColor('--fr-gray-100'),
    200: varColor('--fr-gray-200'),
    300: varColor('--fr-gray-300'),
    400: varColor('--fr-gray-400'),
    500: varColor('--fr-gray-500'),
    600: varColor('--fr-gray-600'),
    700: varColor('--fr-gray-700'),
    800: varColor('--fr-gray-800'),
    900: varColor('--fr-gray-900'),
};

// Semantic status colours for server state indicators. Kept at the 50/400/500 shape
// the existing StatusIndicator component expects. The `50` tints and `500` text
// colours are variable-backed: a pale wash only works on a light background, and a
// mid-tone text colour only passes contrast on one of the two.
const status = {
    running: { 50: varColor('--fr-running-50'), 400: '#4ADE80', 500: varColor('--fr-running-500') },
    pending: { 50: varColor('--fr-pending-50'), 400: '#FBBF24', 500: varColor('--fr-pending-500') },
    offline: { 50: varColor('--fr-offline-50'), 400: '#F87171', 500: varColor('--fr-offline-500') },
    processing: { 50: varColor('--fr-processing-50'), 400: '#5B9BFF', 500: varColor('--fr-processing-500') },
    unknown: { 50: varColor('--fr-unknown-50'), 400: '#94A3B8', 500: varColor('--fr-unknown-500') },
};

module.exports = {
    // The theme is chosen by an admin under Admin → Settings → Theme and rendered as
    // `data-theme` on <html> by templates/wrapper.blade.php, so there is no `.dark`
    // class and no client-side toggle to keep in sync.
    darkMode: ['selector', 'html[data-theme="dark"]'],
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
        // Only the two user-facing wrapper templates — so the `body` class they set is
        // actually generated. The admin Blade views are deliberately excluded; they run
        // on AdminLTE and never load this stylesheet.
        './resources/views/templates/**/*.blade.php',
    ],
    theme: {
        extend: {
            screens: {
                xs: '480px',
            },
            fontFamily: {
                header: ['"Plus Jakarta Sans"', '"IBM Plex Sans"', 'system-ui', 'sans-serif'],
                sans: ['"Plus Jakarta Sans"', '"IBM Plex Sans"', 'system-ui', 'sans-serif'],
                mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
            },
            colors: {
                black: '#040E24',
                // "primary", "neutral" and "soft-blue" are all aliases kept for
                // backwards compatibility with existing markup — they now resolve to
                // the FR3NEWERA ramps so older components inherit the new palette
                // without needing to be rewritten.
                primary: blue,
                blue: blue,
                'soft-blue': blue,
                gray: gray,
                neutral: gray,
                // The panel/card fill. Use this rather than `bg-white` in new code — it is
                // theme-aware, `white` is literally white in both themes.
                surface: varColor('--fr-surface'),
                // The recessed fill behind text inputs and selects.
                field: varColor('--fr-field'),
                navy: {
                    700: '#0F3480',
                    800: '#0D2251',
                    900: '#0B1836',
                    950: '#040E24',
                },
                cyan: colors.cyan,
                status: status,
                // Terminal and code surfaces are dark in BOTH themes — a console reads
                // better that way, and the reference site keeps its code blocks dark even
                // on light pages. These are literal so they never follow the neutral ramp
                // when it inverts.
                code: {
                    bg: '#0D1117',
                    chrome: '#1E293B',
                    border: '#1E293B',
                    text: '#E6EDF3',
                    muted: '#8B949E',
                },
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            spacing: {
                18: '4.5rem',
                22: '5.5rem',
            },
            borderRadius: {
                field: '14px',
                card: '18px',
                'card-lg': '22px',
                'card-xl': '28px',
                xl2: '1.25rem',
            },
            boxShadow: {
                // Blue-tinted on light — a large part of what makes the reference design
                // read as "FR3NEWERA" — but near-black on dark, where a blue glow reads as
                // haze rather than depth. See the shadow variables in assets/tailwind.css.
                'soft-sm': 'var(--fr-shadow-soft-sm)',
                soft: 'var(--fr-shadow-soft)',
                'soft-lg': 'var(--fr-shadow-soft-lg)',
                card: 'var(--fr-shadow-card)',
                'card-hover': 'var(--fr-shadow-card-hover)',
                // The brand-blue glows under buttons are identical in both themes.
                btn: '0 8px 28px -4px rgba(15, 98, 254, 0.35)',
                'btn-hover': '0 14px 36px -6px rgba(15, 98, 254, 0.45)',
                glass: 'var(--fr-shadow-glass)',
                dock: 'var(--fr-shadow-dock)',
                inset: 'inset 0 0 0 1px rgba(255, 255, 255, 0.05)',
            },
            transitionDuration: {
                180: '180ms',
                220: '220ms',
                250: '250ms',
            },
            transitionTimingFunction: {
                'soft-out': 'cubic-bezier(0.16, 1, 0.3, 1)',
                spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
            },
            keyframes: {
                'fr-drift-a': {
                    '0%': { transform: 'translate(0, 0) scale(1)' },
                    '100%': { transform: 'translate(60px, 50px) scale(1.15)' },
                },
                'fr-drift-b': {
                    '0%': { transform: 'translate(0, 0) scale(1)' },
                    '100%': { transform: 'translate(-50px, -40px) scale(1.1)' },
                },
                'fr-pulse-dot': {
                    '0%, 100%': { opacity: '1', boxShadow: '0 0 6px #4AFF91' },
                    '50%': { opacity: '0.5', boxShadow: '0 0 16px #4AFF91' },
                },
                'fr-shine': {
                    '0%': { left: '-100%' },
                    '100%': { left: '100%' },
                },
                // The entrance animations below all settle on `transform: none` rather
                // than an identity transform. An element left with *any* transform value
                // becomes the containing block for its fixed-position descendants — which
                // is what pulled Google's fixed reCAPTCHA badge into the middle of the
                // login card, since these run with `animation-fill-mode: both`.
                'fr-rise-in': {
                    '0%': { opacity: '0', transform: 'translateY(32px) scale(0.97)' },
                    '100%': { opacity: '1', transform: 'none' },
                },
                'fr-fade-down': {
                    '0%': { opacity: '0', transform: 'translateY(-16px)' },
                    '100%': { opacity: '1', transform: 'none' },
                },
                'fr-fade-up': {
                    '0%': { opacity: '0', transform: 'translateY(24px)' },
                    '100%': { opacity: '1', transform: 'none' },
                },
                'fr-shimmer': {
                    '0%': { backgroundPosition: '200% 0' },
                    '100%': { backgroundPosition: '-200% 0' },
                },
            },
            animation: {
                'fr-drift-a': 'fr-drift-a 12s ease-in-out infinite alternate',
                'fr-drift-b': 'fr-drift-b 15s ease-in-out infinite alternate',
                'fr-pulse-dot': 'fr-pulse-dot 2s ease-in-out infinite',
                'fr-rise-in': 'fr-rise-in 0.7s cubic-bezier(0.23, 1, 0.32, 1) both',
                'fr-fade-down': 'fr-fade-down 0.65s cubic-bezier(0.23, 1, 0.32, 1) both',
                'fr-fade-up': 'fr-fade-up 0.7s cubic-bezier(0.16, 1, 0.3, 1) both',
                'fr-shimmer': 'fr-shimmer 1.6s linear infinite',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ],
};
